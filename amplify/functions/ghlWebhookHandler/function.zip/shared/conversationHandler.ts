import axios from 'axios';
import { analyzeBridgeProperty } from '../../../app/utils/bridge.server';

const GHL_API_KEY = process.env.GHL_API_KEY;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

// Conversation states
type ConversationState = 
  | 'NEW_LEAD'
  | 'ASK_INTENT'
  | 'BUYER_QUALIFICATION'
  | 'SELLER_QUALIFICATION'
  | 'PROPERTY_VALUATION'
  | 'APPOINTMENT_BOOKING'
  | 'QUALIFIED';

// Conversation goal tracking
type ConversationGoal = {
  primary: 'schedule_visit' | 'get_price_expectation' | 'disqualify';
  blockers: string[];
  urgencyLevel: 'low' | 'medium' | 'high';
  sentiment?: 'POSITIVE' | 'NEUTRAL' | 'FRUSTRATED' | 'URGENT' | 'DISENGAGING';
};

interface ConversationContext {
  contactId: string;
  conversationId: string;
  incomingMessage: string;
  contactName: string;
  propertyAddress?: string;
  propertyCity?: string;
  propertyState?: string;
  propertyZip?: string;
  propertyLat?: number;
  propertyLng?: number;
  leadType?: string;
  locationId: string;
  contact?: any; // Full contact object for field checking
  testMode?: boolean; // If true, don't send messages to GHL
  fromNumber?: string; // Phone number to send SMS from
  accessToken?: string; // GHL OAuth token for API calls
  messageType?: 'SMS' | 'FB' | 'IG' | 'WhatsApp'; // Message channel type
  existingZestimate?: number; // Zestimate from database (skip API call)
  existingCashOffer?: number; // Cash offer from database (skip calculation)
  conversationHistory?: Array<{role: 'user' | 'assistant', content: string}>; // Last 20 messages for context
  // Listing ad context (for buyer leads)
  listingAddress?: string; // Property from the ad
  listingPrice?: number;
  listingBeds?: number;
  listingBaths?: number;
  listingType?: string; // Single Family, Condo, etc.
  listingCity?: string;
  listingState?: string;
  leadIntent?: 'buyer' | 'seller'; // Determined from ad or conversation
  // State tracking
  conversationState?: ConversationState;
  conversationGoal?: ConversationGoal;
  budget?: string;
  timeline?: string;
  location?: string;
  motivation?: string;
}

interface PropertyAnalysis {
  zestimate?: number;
  sqft?: number;
  beds?: number;
  baths?: number;
  yearBuilt?: number;
}

// Simple sentiment detection (only for messages > 10 chars)
async function detectSentiment(message: string): Promise<'POSITIVE' | 'NEUTRAL' | 'FRUSTRATED' | 'URGENT' | 'DISENGAGING' | null> {
  if (message.length <= 10) return null;
  
  // Check for objection keywords first (fast path)
  const objectionKeywords = ['not interested', 'stop', 'remove', 'unsubscribe', 'leave me alone', 'busy', 'later'];
  if (objectionKeywords.some(kw => message.toLowerCase().includes(kw))) {
    return 'DISENGAGING';
  }

  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4o-mini', // Cheap for simple classification
        messages: [{
          role: 'system',
          content: 'Classify the user\'s message as: POSITIVE | NEUTRAL | FRUSTRATED | URGENT | DISENGAGING\n\nOnly return the label.'
        }, {
          role: 'user',
          content: message
        }],
        temperature: 0,
        max_tokens: 10
      },
      {
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const sentiment = response.data.choices[0].message.content.trim().toUpperCase();
    if (['POSITIVE', 'NEUTRAL', 'FRUSTRATED', 'URGENT', 'DISENGAGING'].includes(sentiment)) {
      return sentiment as any;
    }
    return 'NEUTRAL';
  } catch (error) {
    console.error('Sentiment detection failed:', error);
    return null;
  }
}

// Detect conversation-ending signals (CRITICAL for preventing over-messaging)
function isConversationEnd(message: string): boolean {
  const endSignals = [
    'ok thanks',
    'thanks',
    'thank you',
    'all good',
    'all set',
    'appreciate it',
    "we're fine",
    "we're good",
    'got it',
    'okay',
    'ok',
    'thx',
    'ty'
  ];
  
  const normalized = message.toLowerCase().trim();
  
  // Exact match or very short acknowledgment
  if (endSignals.includes(normalized)) {
    return true;
  }
  
  // Short message (< 15 chars) containing end signal
  if (normalized.length < 15 && endSignals.some(signal => normalized.includes(signal))) {
    return true;
  }
  
  return false;
}

// Detect hard objections (property not for sale)
function isHardObjection(message: string): boolean {
  const hardObjections = [
    'not for sale',
    'not selling',
    'keeping it',
    'keeping the property',
    'family is keeping',
    'already sold',
    'have an agent',
    'have a realtor',
    'working with',
    'already listed',
    'not interested'
  ];
  
  const normalized = message.toLowerCase();
  return hardObjections.some(objection => normalized.includes(objection));
}

// Get property analysis using Bridge API with address variations and coordinate fallback
async function getPropertyAnalysis(address: string, city: string, state: string, zip: string, lat?: number, lng?: number): Promise<PropertyAnalysis | null> {
  try {
    console.log('🏠 Fetching property data with address variations...');
    
    const result = await analyzeBridgeProperty({
      street: address,
      city,
      state,
      zip,
      lat,
      lng
    });

    if (!result.success || !result.valuation) {
      console.log('⚠️ No property data found');
      return null;
    }
    
    console.log('✅ Property data retrieved:', {
      zestimate: result.valuation.zestimate,
      address: result.valuation.address
    });
    
    return {
      zestimate: result.valuation.zestimate,
      sqft: result.valuation.livingArea,
      beds: result.valuation.bedrooms,
      baths: result.valuation.bathrooms,
      yearBuilt: result.valuation.yearBuilt
    };
  } catch (error: any) {
    console.error('❌ Property analysis error:', error.message);
    return null;
  }
}

// Send message to GHL
async function sendGHLMessage(conversationId: string, message: string, accessToken: string, testMode = false, fromNumber?: string, contactId?: string, messageType: string = 'SMS') {
  if (testMode) {
    console.log('🧪 TEST MODE - Would send message:', message);
    return;
  }
  
  try {
    console.log(`📤 Sending ${messageType} message to GHL ${contactId ? `contact ${contactId}` : `conversation ${conversationId}`}`);
    
    const messagePayload: any = {
      type: messageType, // SMS, FB, IG, WhatsApp
      message
    };
    
    // Add fromNumber if provided (SMS only)
    if (fromNumber && messageType === 'SMS') {
      messagePayload.fromNumber = fromNumber;
    }
    
    // Use contact-based endpoint if contactId provided (auto-creates conversation)
    const endpoint = contactId 
      ? `https://services.leadconnectorhq.com/conversations/messages`
      : `https://services.leadconnectorhq.com/conversations/${conversationId}/messages`;
    
    if (contactId) {
      messagePayload.contactId = contactId;
    }
    
    const response = await axios.post(
      endpoint,
      messagePayload,
      {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          'Version': '2021-07-28',
          'Accept': 'application/json'
        }
      }
    );
    console.log(`✅ ${messageType} message sent successfully to GHL`);
  } catch (error: any) {
    console.error(`❌ Failed to send GHL ${messageType} message:`, error.response?.data || error.message);
    throw error;
  }
}

// Generate AI response using OpenAI with tool calling
async function generateOpenAIResponse(context: ConversationContext, propertyData?: PropertyAnalysis, currentState?: ConversationState, nextState?: ConversationState): Promise<string> {
  // Use existing Zestimate from database if available (faster, no API call)
  const zestimate = context.existingZestimate || propertyData?.zestimate;
  const cashOffer = context.existingCashOffer || (zestimate ? Math.round(zestimate * 0.70) : null);
  
  const hasPropertyData = !!zestimate;
  const hasAddress = context.propertyAddress && context.propertyCity && context.propertyState;
  
  const propertyInfo = hasPropertyData ? 
    `Property Details: ${context.propertyAddress}, ${context.propertyCity}, ${context.propertyState} ${context.propertyZip}
    Estimated Value: $${zestimate?.toLocaleString() || 'N/A'}
    ${propertyData?.sqft ? `Square Feet: ${propertyData.sqft}` : ''}
    ${propertyData?.beds ? `Bedrooms: ${propertyData.beds}` : ''}
    ${propertyData?.baths ? `Bathrooms: ${propertyData.baths}` : ''}
    ${propertyData?.yearBuilt ? `Year Built: ${propertyData.yearBuilt}` : ''}` : '';

  const offerInfo = cashOffer && hasPropertyData ? 
    `\nOFFER OPTIONS:
    - AS-IS CASH OFFER: $${cashOffer.toLocaleString()} (70% of market value, quick close)
    - RETAIL LISTING: $${zestimate?.toLocaleString()} (maximum value, traditional sale)` : '';

  // Adapt script based on available data
  const isInitialOutreach = context.incomingMessage === 'initial_outreach';
  const isFollowUp = context.incomingMessage?.startsWith('follow_up_touch_');
  const touchNumber = isFollowUp ? parseInt(context.incomingMessage.split('_')[3]) : 1;
  
  // 🛑 HARD-CODED TEMPLATES: Do not let AI generate these
  // Return exact compliance-approved messages for all touches
  if (isInitialOutreach || isFollowUp) {
    const firstName = context.contactName.split(' ')[0];
    const streetName = context.propertyAddress 
      ? context.propertyAddress.split(',')[0].replace(/^\d+\s+/, '') 
      : 'your street';

    const templates: Record<number, string> = {
      1: `Hi ${firstName}, this is Jose with RE/MAX. I'm reaching out based on public information about a property on ${streetName} — just wanted to confirm whether it's something you're planning to sell or keep. Reply STOP to opt out.`,
      2: `Hi ${firstName}, Jose from RE/MAX here. Just wanted to see if you got my last text about the property. Still a good time to talk?`,
      3: `Hi ${firstName}, Jose again. I've been working with a few families in your area lately. Would love to share what I'm seeing in the market if you're curious. Reply STOP to opt out.`,
      4: `${firstName}, quick question — if you were to move forward, would you prefer a fast cash offer or taking time to list for top dollar? Just want to know which direction makes sense for you.`,
      5: `${firstName}, I'm looking for one more property in your area this month. If you're open to discussing options, let me know soon. Otherwise, no worries!`,
      6: `${firstName}, I haven't heard back so I'll assume you aren't interested right now. I'll take you off my list. Best of luck with everything!`,
      7: `Last try, ${firstName}! Keeping your info on file in case things change down the road. Feel free to reach out anytime. - Jose`
    };

    const message = templates[touchNumber] || templates[1];
    console.log(`📤 Using hard-coded template for touch ${touchNumber}`);
    return message;
  }
  
  // Use provided state or calculate it (only for replies, not outreach)
  const calculatedCurrentState = currentState ?? getCurrentState(context.contact);
  const hasAddressForState = !!(context.propertyAddress && context.propertyCity && context.propertyState);
  const calculatedNextState = nextState ?? getNextState(calculatedCurrentState, context.incomingMessage, hasAddressForState, context.leadIntent);

  const systemPrompt = `You are an AI assistant helping Jose Fernandez, a licensed real estate agent at RE/MAX Homeland Realtors.

📱 COMMUNICATION PREFERENCE OVERRIDE (HIGHEST PRIORITY):

If the user requests a specific communication method:
- "Text me" / "Please text" / "Send me a text"
- "Call me" / "Give me a call"
- "Email me" / "Send an email"

IMMEDIATELY acknowledge and continue naturally:
"Absolutely! I'm texting you now. [Continue with relevant question based on conversation state]"

DO NOT treat this as a trust question. This is a preference, not skepticism.

🔒 TRUST QUESTION OVERRIDE (SECOND PRIORITY):

If the user asks a trust question with question words or question marks:
- "Where did you see this?" / "How did you get my info?"
- "What notice?" / "Who gave you my number?"
- "Where did you see the notice?" / "How did you find me?"

IMMEDIATELY respond with ONE of these variants (choose randomly):

Variant 1: "Good question — it came from publicly available county records. Nothing private or paid. If this isn't a good time, no worries at all."

Variant 2: "It came from publicly available county records — nothing private. Let me know if you'd like to discuss options."

Variant 3: "I saw it through public county filings. No special access. Happy to answer any questions."

DO NOT:
- Ask questions back
- Mention selling before they respond
- Repeat the property address

Just answer directly and stop. Trust must be restored before continuing.

COMPLIANCE RULES (CRITICAL):
1. IDENTIFY AS AI: Only if asked directly ("Are you a bot?", "Is this automated?"). Otherwise, represent Jose naturally.
2. NO LEGAL/FINANCIAL ADVICE: Never give tax, legal, or financial advice
3. HUMAN HANDOFF: Complex questions → "Let me connect you with Jose directly"
4. DISCLAIMERS: Property values are estimates only, not appraisals
5. ALREADY LISTED PROPERTIES: If they mention working with another realtor or property being listed, IMMEDIATELY exit gracefully
6. NEVER REPEAT FULL ADDRESS: After initial outreach, do not repeat the full property address unless the user mentions it first

ALREADY LISTED PROPERTY PROTOCOL:
If they mention:
- "We're working with [realtor name]"
- "It's already listed"
- "We have a realtor"
- "Listed with [brokerage]"
- Any indication of existing representation

RESPOND WITH:
"I understand you're already working with [realtor name/brokerage]. I respect that relationship and wish you the best with your sale! If anything changes in the future, feel free to reach out."

THEN: Use end_conversation tool to mark as completed and stop all follow-ups.

NOT INTERESTED / KEEPING PROPERTY PROTOCOL:
If they say:
- "Not interested"
- "Not selling"
- "We're keeping it"
- "Keeping the property"
- "Not for sale"

RESPOND WITH:
"I understand. If anything changes down the road, feel free to reach out. Best of luck!"

THEN: Use end_conversation tool with reason 'not_interested' to stop all follow-ups for 120 days.

CONVERSATION STATE: ${calculatedNextState}

STATE-SPECIFIC GUIDANCE:

${calculatedNextState === 'NEW_LEAD' || calculatedNextState === 'ASK_INTENT' ? `
🎯 GOAL: Determine if buyer or seller
ASK: "Are you looking to buy or thinking about selling?"
` : ''}

${calculatedNextState === 'SELLER_QUALIFICATION' ? `
🎯 GOAL: Get property address
ASK: "What's the address?" (if not provided)
THEN: Use validate_address tool
` : ''}

${calculatedNextState === 'PROPERTY_VALUATION' ? `
🎯 GOAL: Show property value and present options
ACTION: Use get_property_value tool
THEN: "Based on current market data, your property is valued around $X. I can offer you $Y cash for a quick close, or help you list it for the full $X. Which interests you more?"
` : ''}

${calculatedNextState === 'BUYER_QUALIFICATION' ? `
🎯 GOAL: Qualify buyer and save search
ASK ONE AT A TIME:
1. "What area are you looking in?"
2. "What's your budget?"
3. "How many bedrooms?"
4. "When are you hoping to move?"
THEN: Use save_buyer_search tool
` : ''}

${calculatedNextState === 'APPOINTMENT_BOOKING' ? `
🎯 GOAL: Book consultation
ACTION: Use check_availability tool
THEN: Present 2-3 time slots
THEN: Use schedule_consultation tool
` : ''}

${calculatedNextState === 'QUALIFIED' ? `
🎯 GOAL: Confirm appointment and set expectations
SAY: "Perfect! I'll send you a calendar invite. Looking forward to meeting you!"
` : ''}

CONVERSATION CONTEXT:
- Contact: ${context.contactName}
- Their message: "${context.incomingMessage}"
${hasAddress ? `- Known property: ${context.propertyAddress}` : ''}
${context.leadIntent ? `- Intent: ${context.leadIntent}` : ''}

SCENARIO 1: EXISTING LEAD (Has property address in system)
${hasAddress ? `
You already know about their ${context.leadType?.toLowerCase() || 'property'} situation at ${context.propertyAddress}.

CONVERSATION APPROACH:
- Acknowledge their response naturally
- If interested: Present cash offer vs listing options
- If asking about value: Use get_property_value tool
- If hesitant: Address concerns, build trust
- Goal: Schedule 10-minute property walkthrough

EXAMPLE:
Them: "Yes, still interested"
You: "Great! I wanted to see if I could make you a firm cash offer to buy it directly, or help you list it for maximum value. I work with families in these situations because having both options gives you the most control. I just need 10 minutes to see the condition. Are you open to meeting this week?"
` : `
SCENARIO 2: NEW LEAD (No property info - FB ad, website, etc.)

NATURAL CONVERSATION STYLE:
- Talk like a helpful neighbor, not a salesperson
- Use casual language: "Hey", "I'd love to help", "Let me check on that"
- Show genuine interest in their situation
- Keep responses SHORT (1-2 sentences max)

DISCOVERY FLOW:

If they ask about a specific property:
Example: "I don't see 305 Union Ave listed right now, but I can dig into it for you! Are you looking to buy in Belleville?"

STEP 1: DETERMINE INTENT (casual approach)
- "Are you looking to buy or thinking about selling?"
- OR "What brings you to the area - buying or selling?"

STEP 2A: FOR SELLERS - Get Info Naturally
Ask naturally (one at a time):
1. "What's the address?"
2. "What's got you thinking about selling?"
3. "Any timeline in mind?"

Then use tools:
- validate_address (when they give address)
- get_property_value (after validation)
- Present options naturally: "I can either make you a cash offer or help you list it for top dollar. Want to chat about both?"

STEP 2B: FOR BUYERS - Qualify Naturally
Ask one at a time:
1. "What area are you looking in?"
2. "Any other neighborhoods you're considering?"
3. "What's your budget looking like?"
4. "How many bedrooms?"
5. "When are you hoping to move?"

Then: save_buyer_search tool

${context.conversationGoal ? `
CONVERSATION GOAL:
Primary Objective: ${context.conversationGoal.primary.replace(/_/g, ' ').toUpperCase()}
Urgency Level: ${context.conversationGoal.urgencyLevel.toUpperCase()}
${context.conversationGoal.sentiment ? `Current Sentiment: ${context.conversationGoal.sentiment}` : ''}

${context.conversationGoal.sentiment === 'FRUSTRATED' ? 
  '⚠️ IMPORTANT: User seems frustrated. Slow down, empathize, offer human assistance. Keep response to 2 sentences max.' : ''}
${context.conversationGoal.sentiment === 'URGENT' ? 
  '⚡ IMPORTANT: User is urgent. Move quickly to CTA, be direct and action-oriented.' : ''}
${context.conversationGoal.sentiment === 'DISENGAGING' ? 
  '🚨 CRITICAL: User is disengaging. Keep response to 1 sentence. Ask ONE simple yes/no question.' : ''}
` : ''}

CONVERSATION RULES:
- ONE question at a time
- Sound like texting a friend
- No corporate speak
- Use contractions (I'm, you're, let's)
- Be brief - 1-2 sentences max

🛑 CRITICAL - WHEN TO STOP:
- If user says "ok thanks", "thanks", "all good" → DO NOT RESPOND
- If user says "keeping it", "not for sale" → Send ONE polite close, then STOP
- After a polite close, if they acknowledge → SILENCE IS SUCCESS
- In outbound conversations, silence after acknowledgment is professional, not failure
- DO NOT try to "save the deal" after a clear exit signal
`}

TOOLS AVAILABLE:
- validate_address: Standardize address (new leads only)
- get_property_value: Get Zestimate (when address known)
- schedule_consultation: Book consultation (when qualified)

${propertyInfo}${offerInfo}

RESPONSE STYLE:
- Text like a real person, not a bot
- 1-2 sentences max
- Use casual language
- Show personality
- Be helpful, not salesy

Respond to their message:`;

  try {
    console.log('🤖 Calling OpenAI for message generation...');
    console.log(`📝 Context: ${isInitialOutreach ? 'Initial outreach' : 'Reply'} for ${context.contactName}`);
    
    const tools = [
      {
        type: 'function',
        function: {
          name: 'validate_address',
          description: 'Validate and standardize an address using Google Maps. Use this FIRST before getting property value.',
          parameters: {
            type: 'object',
            properties: {
              address: { type: 'string', description: 'Full address string (e.g., "123 Main St, Miami, FL 33101")' }
            },
            required: ['address']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'get_property_value',
          description: 'Get Zestimate and property details. Use AFTER validating address with validate_address tool.',
          parameters: {
            type: 'object',
            properties: {
              street: { type: 'string', description: 'Street address (e.g., "123 Main St")' },
              city: { type: 'string', description: 'City name' },
              state: { type: 'string', description: 'State abbreviation (e.g., "FL")' },
              zip: { type: 'string', description: 'ZIP code' },
              lat: { type: 'number', description: 'Latitude from validated address' },
              lng: { type: 'number', description: 'Longitude from validated address' }
            },
            required: ['street', 'city', 'state', 'zip']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'check_availability',
          description: 'Check available appointment slots. Use this BEFORE scheduling.',
          parameters: {
            type: 'object',
            properties: {
              startDate: { type: 'string', description: 'Start date (YYYY-MM-DD)' },
              endDate: { type: 'string', description: 'End date (YYYY-MM-DD)' }
            },
            required: ['startDate', 'endDate']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'schedule_consultation',
          description: 'Schedule appointment in an available slot. Use AFTER checking availability.',
          parameters: {
            type: 'object',
            properties: {
              consultationType: { type: 'string', enum: ['buyer', 'seller'], description: 'Type of consultation' },
              startTime: { type: 'string', description: 'ISO 8601 datetime from available slots' }
            },
            required: ['consultationType', 'startTime']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'save_buyer_search',
          description: 'Save buyer search criteria in kvCORE for automated property alerts. Use ONLY after asking about additional areas.',
          parameters: {
            type: 'object',
            properties: {
              cities: { 
                type: 'array', 
                items: { type: 'string' },
                description: 'Array of city names buyer is interested in (e.g., ["Miami", "Fort Lauderdale"])' 
              },
              state: { type: 'string', description: 'State abbreviation' },
              minPrice: { type: 'number', description: 'Minimum price' },
              maxPrice: { type: 'number', description: 'Maximum price' },
              beds: { type: 'number', description: 'Minimum bedrooms' },
              baths: { type: 'number', description: 'Minimum bathrooms' },
              propertyTypes: { type: 'array', items: { type: 'string' }, description: 'Property types (Single Family, Condo, etc.)' }
            },
            required: ['cities', 'state', 'maxPrice']
          }
        }
      },
      {
        type: 'function',
        function: {
          name: 'end_conversation',
          description: 'End conversation when prospect is already working with another realtor or property is already listed. Marks conversation as completed to stop follow-ups.',
          parameters: {
            type: 'object',
            properties: {
              reason: { 
                type: 'string', 
                description: 'Reason for ending (e.g., "already_listed", "has_realtor", "not_interested")' 
              }
            },
            required: ['reason']
          }
        }
      }
    ];
    
    // Build messages array with conversation history
    const messages: Array<{role: string, content: string}> = [
      { role: 'system', content: systemPrompt }
    ];
    
    // Add conversation history if available (for multi-turn context)
    if (context.conversationHistory && context.conversationHistory.length > 0) {
      messages.push(...context.conversationHistory);
      console.log(`📜 Including ${context.conversationHistory.length} previous messages for context`);
    }
    
    // Add current message
    if (isInitialOutreach) {
      messages.push({ role: 'user', content: 'Generate the initial outreach message following the 5-step script.' });
    } else {
      messages.push({ role: 'user', content: context.incomingMessage });
    }
    
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-4o-mini', // Using 4o-mini for now (4.1-mini when available)
        messages,
        tools,
        tool_choice: 'auto',
        max_tokens: 150,
        temperature: 0.6, // Slightly lower for more consistent responses
      },
      {
        headers: {
          'Authorization': `Bearer ${OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const choice = response.data.choices[0];
    
    // Check if AI wants to use a tool
    if (choice.finish_reason === 'tool_calls' && choice.message.tool_calls) {
      console.log('🔧 AI requested tool call:', choice.message.tool_calls[0].function.name);
      
      const toolCall = choice.message.tool_calls[0];
      const toolName = toolCall.function.name;
      const args = JSON.parse(toolCall.function.arguments);
      
      if (toolName === 'validate_address') {
        console.log('🗺️ Validating address:', args.address);
        const { validateAddressWithGoogle } = await import('../../../app/utils/google.server');
        const validated = await validateAddressWithGoogle(args.address);
        
        if (validated?.success) {
          const { street, city, state, zip } = validated.components;
          const { lat, lng } = validated.location as any;
          
          // Now get property value with validated address
          const propData = await getPropertyAnalysis(street, city, state, zip, lat, lng);
          
          if (propData?.zestimate) {
            const cashOffer = Math.round(propData.zestimate * 0.70);
            return `Perfect! I found your property at ${validated.formattedAddress}. Current market value is around $${propData.zestimate.toLocaleString()}. I can offer $${cashOffer.toLocaleString()} cash for a quick close, or help you list it for the full $${propData.zestimate.toLocaleString()}. Which interests you more?`;
          } else {
            return `I found your address at ${validated.formattedAddress}, but I'd need to see the property in person to give you an accurate value. Can we schedule a quick 10-minute walkthrough this week?`;
          }
        } else {
          return `I'm having trouble finding that address. Could you provide the full street address, city, and ZIP code?`;
        }
      }
      
      if (toolName === 'get_property_value') {
        console.log('📍 Fetching property value for:', args);
        const propData = await getPropertyAnalysis(args.street, args.city, args.state, args.zip, args.lat, args.lng);
        
        if (propData?.zestimate) {
          const cashOffer = Math.round(propData.zestimate * 0.70);
          return `Based on current market data, your property at ${args.street} is valued around $${propData.zestimate.toLocaleString()}. I can offer you $${cashOffer.toLocaleString()} cash for a quick close, or help you list it for the full $${propData.zestimate.toLocaleString()}. Which option interests you more?`;
        } else {
          return `I'd need to see the property to give you an accurate value. Can we schedule a quick 10-minute walkthrough this week?`;
        }
      }
      
      if (toolName === 'schedule_consultation') {
        console.log('📅 Scheduling consultation:', args);
        const leadType = args.lead_type === 'seller' ? 'seller' : 'buyer';
        
        // Tag contact for human handoff
        return `Great! I'll have one of our ${leadType} specialists reach out within the next few hours to schedule your consultation. Thanks for your interest!`;
      }
      
      if (toolName === 'check_availability') {
        console.log('📅 Checking availability:', args);
        
        try {
          const response = await fetch(
            `https://services.leadconnectorhq.com/calendars/tuC1rqAOzPTThWUC7rvS/free-slots?startDate=${args.startDate}&endDate=${args.endDate}`,
            {
              headers: {
                'Accept': 'application/json',
                'Authorization': `Bearer ${context.accessToken}`,
                'Version': '2021-07-28'
              }
            }
          );
          
          const data = await response.json();
          
          // Format slots for AI
          if (data.slots && data.slots.length > 0) {
            const formattedSlots = data.slots.slice(0, 5).map((slot: any) => 
              new Date(slot).toLocaleString('en-US', { 
                weekday: 'short', 
                month: 'short', 
                day: 'numeric', 
                hour: 'numeric', 
                minute: '2-digit' 
              })
            );
            return `Available times: ${formattedSlots.join(', ')}. Raw slots: ${JSON.stringify(data.slots.slice(0, 5))}`;
          }
          
          return 'No available slots found in that date range.';
        } catch (error) {
          console.error('Failed to check availability:', error);
          return 'Unable to check availability right now.';
        }
      }

      if (toolName === 'schedule_consultation') {
        console.log('📅 Scheduling consultation:', args);
        
        const isBuyer = args.consultationType === 'buyer';
        const description = isBuyer 
          ? 'Join us for a personalized buyer consultation where we\'ll discuss your home search criteria, budget, timeline, and answer all your questions about the buying process. We\'ll also show you how to get pre-approved and find your dream home.'
          : 'Join us for a seller consultation where we\'ll review your property, discuss current market conditions, pricing strategy, and our comprehensive marketing plan to get you the best price for your home.';
        
        try {
          const response = await fetch('https://services.leadconnectorhq.com/calendars/events/appointments', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${context.accessToken}`,
              'Version': '2021-07-28'
            },
            body: JSON.stringify({
              calendarId: 'tuC1rqAOzPTThWUC7rvS',
              locationId: context.locationId,
              contactId: context.contact?.id,
              startTime: args.startTime,
              endTime: new Date(new Date(args.startTime).getTime() + 60*60*1000).toISOString(),
              title: isBuyer ? 'Buyer Consultation' : 'Seller Consultation',
              description: description,
              appointmentStatus: 'confirmed',
              assignedUserId: context.contact?.ownerId || context.contact?.assignedTo,
              meetingLocationType: 'google_conference',
              toNotify: true
            })
          });
          
          const appointment = await response.json();
          return `Perfect! I've scheduled your ${args.consultationType} consultation for ${new Date(args.startTime).toLocaleString()}. You'll receive a Google Meet link and reminders via text and email.`;
        } catch (error) {
          console.error('Failed to schedule appointment:', error);
          return 'I had trouble scheduling that appointment. Let me transfer you to someone who can help.';
        }
      }

      if (toolName === 'save_buyer_search') {
        console.log('💾 Saving buyer search to kvCORE:', args);
        
        try {
          const { createContact, addSearchAlert } = await import('../../../app/utils/kvcore.server');
          
          // Create contact in kvCORE with hashtag to trigger Smart Campaign
          const kvContact = await createContact({
            firstName: context.contactName.split(' ')[0] || 'Buyer',
            lastName: context.contactName.split(' ').slice(1).join(' ') || 'Lead',
            email: context.contact?.email,
            phone: context.contact?.phone,
            dealType: 'buyer',
            source: 'AI Chat - Facebook',
            notes: `Interested in ${args.beds}BR homes in ${args.cities.join(', ')}, ${args.state} under $${args.maxPrice.toLocaleString()}`,
            tags: ['#fbbuyerleads'] // Triggers "Facebook Buyer Leads" Smart Campaign
          });
          
          if (kvContact) {
            // Create areas array from cities
            const areas = args.cities.map((city: string) => ({
              type: 'city',
              name: city
            }));
            
            // Add saved search
            const searchCriteria = {
              types: args.propertyTypes || (context.listingType ? [context.listingType] : ['Single Family', 'Condo']),
              beds: args.beds || context.listingBeds || 3,
              baths: args.baths || context.listingBaths || 2,
              minPrice: args.minPrice || (context.listingPrice ? Math.round(context.listingPrice * 0.9) : undefined),
              maxPrice: args.maxPrice || (context.listingPrice ? Math.round(context.listingPrice * 1.1) : undefined),
              areas: areas,
              frequency: 'daily'
            };
            
            await addSearchAlert(kvContact.id, searchCriteria);
            
            console.log(`✅ Buyer saved in kvCORE with hashtag #fbbuyerleads and auto-alerts for:`, args.cities.join(', '));
            
            const cityList = args.cities.length > 1 
              ? `${args.cities.slice(0, -1).join(', ')} and ${args.cities[args.cities.length - 1]}`
              : args.cities[0];
            
            return `Perfect! I've saved your search for ${cityList}. You'll receive daily emails when new properties match your criteria. I'll also keep you updated via text. Looking forward to helping you find your dream home!`;
          }
        } catch (error) {
          console.error('Failed to save buyer search:', error);
          return `I've noted your preferences and will keep you updated on properties in ${args.cities.join(', ')}. Looking forward to helping you find your dream home!`;
        }
      }

      if (toolName === 'end_conversation') {
        console.log('🛑 Ending conversation:', args.reason);
        
        // Tag contact to stop follow-ups
        if (context.accessToken && context.contactId) {
          try {
            await axios.put(
              `https://services.leadconnectorhq.com/contacts/${context.contactId}`,
              {
                tags: ['conversation_ended', `ended_reason:${args.reason}`]
              },
              {
                headers: {
                  'Authorization': `Bearer ${context.accessToken}`,
                  'Content-Type': 'application/json',
                  'Version': '2021-07-28'
                }
              }
            );
            console.log('✅ Tagged contact to stop follow-ups');
          } catch (error) {
            console.error('Failed to tag contact:', error);
          }
        }
        
        // Return the message that was already generated by AI
        return choice.message.content || "I understand. Best of luck with your real estate needs!";
      }
    }

    const aiMessage = choice.message?.content || 'Thanks for your message. Let me get back to you shortly.';
    
    // Clean up any step-by-step breakdowns and tool call syntax
    let cleanedMessage = aiMessage;
    
    // Remove tool call syntax like (end_conversation), (validate_address), etc.
    cleanedMessage = cleanedMessage.replace(/\([a-z_]+\)/g, '').trim();
    
    // Remove "Step 1:", "Step 2:", etc.
    if (cleanedMessage.includes('Step 1:') || cleanedMessage.includes('Combined Message:')) {
      // Extract just the combined message if present
      const combinedMatch = cleanedMessage.match(/Combined Message:\s*"([^"]+)"/);
      if (combinedMatch) {
        cleanedMessage = combinedMatch[1];
      } else {
        // Remove all step labels and combine
        cleanedMessage = cleanedMessage
          .replace(/Step \d+:.*?\n/g, '')
          .replace(/Combined Message:\s*/g, '')
          .replace(/"/g, '')
          .trim();
      }
    }
    
    console.log(`✅ OpenAI response: ${cleanedMessage.substring(0, 100)}...`);
    return cleanedMessage;
  } catch (error: any) {
    console.error('❌ OpenAI API error:', error.response?.data || error.message);
    console.error('❌ Full error details:', JSON.stringify(error, null, 2));
    throw new Error(`AI response generation failed: ${error.message}`);
  }
}

// Check if contact has AI enabled and is in good standing
function isAIEnabled(contact: any): boolean {
  const hasPhone = contact?.phone;
  const leadType = contact?.customFields?.find((f: any) => f.id === 'oaf4wCuM3Ub9eGpiddrO')?.value;
  const contactType = contact?.customFields?.find((f: any) => f.id === 'pGfgxcdFaYAkdq0Vp53j')?.value;
  
  if (!hasPhone) {
    console.log('❌ Contact has no phone number');
    return false;
  }
  
  // Exclude direct mail only contacts
  if (contactType === 'Direct Mail') {
    console.log('❌ Contact is Direct Mail only');
    return false;
  }
  
  // Check all variations of lead type (case-insensitive)
  const validLeadTypes = [
    'Probate',
    'probate', 
    'PROBATE',
    'PREFORECLOSURE',
    'Preforeclosure',
    'preforeclosure',
    'Pre-Foreclosure',
    'pre-foreclosure'
  ];
  
  if (!leadType || !validLeadTypes.includes(leadType)) {
    console.log(`❌ Invalid or missing lead type: "${leadType}"`);
    return false;
  }
  
  return true;
  
  // 🚨 TODO: Once AI control fields are added to GHL, use this logic:
  // const appPlan = contact?.customFields?.find((f: any) => f.id === 'YEJuROSCNnG9OXi3K8lb')?.value;
  // const accountStatus = contact?.customFields?.find((f: any) => f.id === 'diShiF2bpX7VFql08MVN')?.value;
  // const aiState = contact?.customFields?.find((f: any) => f.id === '1NxQW2kKMVgozjSUuu7s')?.value;
  // const hasAIPlan = appPlan === 'AI';
  // const accountActive = accountStatus === 'active';
  // const aiNotPaused = aiState !== 'paused';
  // return hasAIPlan && accountActive && aiNotPaused;
}

// Update AI state in GHL
async function updateAIState(contactId: string, newState: string, accessToken: string) {
  try {
    await axios.put(
      `https://services.leadconnectorhq.com/contacts/${contactId}`,
      {
        customFields: [
          { id: '1NxQW2kKMVgozjSUuu7s', value: newState }
        ]
      },
      {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
          'Version': '2021-07-28',
          'Accept': 'application/json'
        }
      }
    );
  } catch (error) {
    console.error('Failed to update AI state:', error);
  }
}

// Get current conversation state from contact
function getCurrentState(contact: any): ConversationState {
  const aiStateField = contact?.customFields?.find((f: any) => f.id === '1NxQW2kKMVgozjSUuu7s');
  const currentState = aiStateField?.value;
  
  // Map old states to new state machine
  if (currentState === 'handoff' || currentState === 'qualified') return 'QUALIFIED';
  if (currentState === 'valuation') return 'PROPERTY_VALUATION';
  
  // Default to NEW_LEAD if no state
  return currentState as ConversationState || 'NEW_LEAD';
}

// Determine next state based on current state and message
function getNextState(currentState: ConversationState, message: string, hasAddress: boolean, intent?: string): ConversationState {
  const msg = message.toLowerCase();
  
  // Check for explicit booking intent
  if (msg.includes('schedule') || msg.includes('appointment') || msg.includes('meet')) {
    return 'APPOINTMENT_BOOKING';
  }
  
  switch (currentState) {
    case 'NEW_LEAD':
      // Determine if buyer or seller
      if (intent === 'seller' || msg.includes('sell') || msg.includes('value') || msg.includes('worth')) {
        return hasAddress ? 'PROPERTY_VALUATION' : 'SELLER_QUALIFICATION';
      }
      if (intent === 'buyer' || msg.includes('buy') || msg.includes('looking for')) {
        return 'BUYER_QUALIFICATION';
      }
      return 'ASK_INTENT';
      
    case 'ASK_INTENT':
      if (msg.includes('sell')) return hasAddress ? 'PROPERTY_VALUATION' : 'SELLER_QUALIFICATION';
      if (msg.includes('buy')) return 'BUYER_QUALIFICATION';
      return 'ASK_INTENT';
      
    case 'SELLER_QUALIFICATION':
      // Once we have address, move to valuation
      if (hasAddress) return 'PROPERTY_VALUATION';
      return 'SELLER_QUALIFICATION';
      
    case 'PROPERTY_VALUATION':
      // After showing value, push to booking
      return 'APPOINTMENT_BOOKING';
      
    case 'BUYER_QUALIFICATION':
      // After qualifying buyer, push to booking
      if (msg.includes('yes') || msg.includes('interested')) {
        return 'APPOINTMENT_BOOKING';
      }
      return 'BUYER_QUALIFICATION';
      
    case 'APPOINTMENT_BOOKING':
      return 'QUALIFIED';
      
    default:
      return currentState;
  }
}

function shouldHandoffToHuman(message: string): boolean {
  const handoffKeywords = [
    'speak to someone',
    'talk to a person',
    'talk to someone',
    'human agent',
    'real person',
    'ready to sell now',
    'schedule a call',
    'call me back'
  ];

  return handoffKeywords.some(keyword => 
    message.toLowerCase().includes(keyword)
  );
}

// Main conversation handler
export async function generateAIResponse(context: ConversationContext): Promise<string> {
  try {
    // Require accessToken for non-test mode
    if (!context.testMode && !context.accessToken) {
      throw new Error('accessToken is required for production mode');
    }

    // Calculate conversation state
    const currentState = getCurrentState(context.contact);
    const hasAddress = !!(context.propertyAddress && context.propertyCity && context.propertyState);
    const nextState = getNextState(currentState, context.incomingMessage, hasAddress, context.leadIntent);
    
    console.log(`📊 Current state: ${currentState}`);
    console.log(`➡️ Next state: ${nextState}`);

    // 🛑 HARD STOP: Check for conversation-ending signals
    if (isConversationEnd(context.incomingMessage)) {
      console.log('🛑 Conversation end signal detected - suppressing AI');
      
      if (!context.testMode && context.accessToken) {
        // Tag as conversation ended
        await axios.post(
          `https://services.leadconnectorhq.com/contacts/${context.contactId}/tags`,
          { tags: ['conversation_ended'] },
          {
            headers: {
              'Authorization': `Bearer ${context.accessToken}`,
              'Content-Type': 'application/json',
              'Version': '2021-07-28'
            }
          }
        );
        
        // Update AI state to stopped
        await updateAIState(context.contactId, 'stopped', context.accessToken);
      }
      
      // DO NOT RESPOND - silence is professionalism
      throw new Error('CONVERSATION_ENDED');
    }

    // 🛑 HARD STOP: Check for hard objections (keeping property, already sold, etc.)
    if (isHardObjection(context.incomingMessage)) {
      console.log('🛑 Hard objection detected - ending conversation gracefully');
      
      if (!context.testMode && context.accessToken) {
        await axios.post(
          `https://services.leadconnectorhq.com/contacts/${context.contactId}/tags`,
          { tags: ['not_for_sale', 'conversation_ended'] },
          {
            headers: {
              'Authorization': `Bearer ${context.accessToken}`,
              'Content-Type': 'application/json',
              'Version': '2021-07-28'
            }
          }
        );
        
        await updateAIState(context.contactId, 'stopped', context.accessToken);
      }
      
      // Send ONE polite close, then stop
      const closeMessage = "I understand. If you ever want to explore options in the future, feel free to reach out. Best of luck!";
      await sendGHLMessage(context.conversationId, closeMessage, context.accessToken || '', context.testMode, context.fromNumber, context.contactId, context.messageType || 'SMS');
      return closeMessage;
    }

    // Detect sentiment for longer messages
    const sentiment = await detectSentiment(context.incomingMessage);
    if (sentiment) {
      console.log(`😊 Sentiment detected: ${sentiment}`);
      
      // Update sentiment in GHL (both tag and custom field)
      if (!context.testMode && context.accessToken) {
        try {
          const sentimentTag = `sentiment:${sentiment.toLowerCase()}`;
          
          // Add sentiment tag
          await axios.post(
            `https://services.leadconnectorhq.com/contacts/${context.contactId}/tags`,
            { tags: [sentimentTag] },
            {
              headers: {
                'Authorization': `Bearer ${context.accessToken}`,
                'Content-Type': 'application/json',
                'Version': '2021-07-28'
              }
            }
          );
          
          // Update sentiment custom field
          await axios.put(
            `https://services.leadconnectorhq.com/contacts/${context.contactId}`,
            {
              customFields: [
                { id: 'vjhwCk3Ns0ekDEbMsuy5', value: sentiment }
              ]
            },
            {
              headers: {
                'Authorization': `Bearer ${context.accessToken}`,
                'Content-Type': 'application/json',
                'Version': '2021-07-28'
              }
            }
          );
          
          console.log(`✅ Updated sentiment: ${sentimentTag} + custom field`);
        } catch (error) {
          console.error('Failed to update sentiment:', error);
        }
      }
    }

    // Determine conversation goal
    const conversationGoal: ConversationGoal = {
      primary: nextState === 'APPOINTMENT_BOOKING' ? 'schedule_visit' : 
               nextState === 'PROPERTY_VALUATION' ? 'get_price_expectation' : 
               'schedule_visit',
      blockers: [],
      urgencyLevel: sentiment === 'URGENT' ? 'high' : 
                    context.leadType === 'PREFORECLOSURE' ? 'high' : 'medium',
      sentiment: sentiment || undefined
    };
    context.conversationGoal = conversationGoal;
    
    // Update state if changed
    if (nextState !== currentState && !context.testMode && context.accessToken) {
      await updateAIState(context.contactId, nextState, context.accessToken);
    }

    // 🛡️ Check if AI is enabled for this contact (skip for organic social media leads)
    const isOrganicSocialLead = context.contact?.attributionSource?.medium === 'facebook' || 
                                 context.contact?.lastAttributionSource?.medium === 'facebook' ||
                                 context.contact?.attributionSource?.medium === 'instagram' || 
                                 context.contact?.lastAttributionSource?.medium === 'instagram';
    
    if (!context.testMode && !isOrganicSocialLead && !isAIEnabled(context.contact)) {
      console.log(`❌ AI disabled for contact ${context.contactId}`);
      throw new Error('AI is not enabled for this contact');
    }

    // Update AI state to running (skip in test mode)
    if (!context.testMode && context.accessToken) {
      await updateAIState(context.contactId, 'running', context.accessToken);
    }

    // Check if human handoff is needed
    if (shouldHandoffToHuman(context.incomingMessage)) {
      // Update AI state to handoff
      if (!context.testMode && context.accessToken) {
        await updateAIState(context.contactId, 'handoff', context.accessToken);
        
        // Tag contact for human follow-up in GHL
        await axios.post(
          `https://services.leadconnectorhq.com/contacts/${context.contactId}/tags`,
          { tags: ['Ready-For-Human-Contact'] },
          {
            headers: {
              'Authorization': `Bearer ${context.accessToken}`,
              'Content-Type': 'application/json',
              'Version': '2021-07-28'
            }
          }
        );
      }

      const handoffMessage = "Great! I'll have one of our property specialists reach out to you within the next few hours to discuss your options. Thanks for your interest!";
      await sendGHLMessage(context.conversationId, handoffMessage, context.accessToken || '', context.testMode, context.fromNumber, context.contactId, context.messageType || 'SMS');
      return handoffMessage;
    }

    // Get property analysis for context
    let propertyData: PropertyAnalysis | null = null;
    if (context.propertyAddress && context.propertyCity && context.propertyState) {
      propertyData = await getPropertyAnalysis(
        context.propertyAddress,
        context.propertyCity,
        context.propertyState,
        context.propertyZip || '',
        context.propertyLat,
        context.propertyLng
      );
    }

    // Generate AI response
    const aiMessage = await generateOpenAIResponse(context, propertyData || undefined, currentState, nextState);

    // Send response to GHL (skip in test mode)
    await sendGHLMessage(context.conversationId, aiMessage, context.accessToken || '', context.testMode, context.fromNumber, context.contactId, context.messageType || 'SMS');

    return aiMessage;

  } catch (error: any) {
    console.error('❌ Conversation handler error:', error);
    console.error('❌ Error details:', JSON.stringify(error, null, 2));
    console.error('❌ Context:', JSON.stringify(context, null, 2));
    throw error; // Don't send fallback - let caller handle error
  }
}
